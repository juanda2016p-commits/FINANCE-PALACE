import { useState } from 'react';
import { Alert, AlertLevel } from '../../types';
import { 
  XCircle, 
  AlertTriangle, 
  Info, 
  CheckCircle, 
  X 
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface AlertsPanelProps {
  alerts: Alert[];
  onDismiss: (id: string) => void;
  onAction?: (alert: Alert) => void;
}

const levelConfig = {
  [AlertLevel.DANGER]: {
    bg: 'bg-red-50',
    border: 'border-red-200',
    text: 'text-red-800',
    icon: XCircle,
    iconColor: 'text-red-500',
    button: 'bg-red-100 text-red-700 hover:bg-red-200'
  },
  [AlertLevel.WARNING]: {
    bg: 'bg-yellow-50',
    border: 'border-yellow-200',
    text: 'text-yellow-800',
    icon: AlertTriangle,
    iconColor: 'text-yellow-500',
    button: 'bg-yellow-100 text-yellow-700 hover:bg-yellow-200'
  },
  [AlertLevel.INFO]: {
    bg: 'bg-indigo-50',
    border: 'border-indigo-200',
    text: 'text-indigo-800',
    icon: Info,
    iconColor: 'text-indigo-500',
    button: 'bg-indigo-100 text-indigo-700 hover:bg-indigo-200'
  },
  [AlertLevel.SUCCESS]: {
    bg: 'bg-emerald-50',
    border: 'border-emerald-200',
    text: 'text-emerald-800',
    icon: CheckCircle,
    iconColor: 'text-emerald-500',
    button: 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200'
  }
};

export default function AlertsPanel({ alerts, onDismiss, onAction }: AlertsPanelProps) {
  // Sort alerts: DANGER > WARNING > INFO > SUCCESS
  const sortedAlerts = [...alerts].sort((a, b) => {
    const order = { 
      [AlertLevel.DANGER]: 0, 
      [AlertLevel.WARNING]: 1, 
      [AlertLevel.INFO]: 2, 
      [AlertLevel.SUCCESS]: 3 
    };
    return order[a.level] - order[b.level];
  });

  if (sortedAlerts.length === 0) return null;

  return (
    <div className="space-y-3 mb-6">
      <AnimatePresence>
        {sortedAlerts.map((alert) => {
          const config = levelConfig[alert.level];
          const Icon = config.icon;

          return (
            <motion.div
              key={alert.id}
              initial={{ opacity: 0, height: 0, marginBottom: 0 }}
              animate={{ opacity: 1, height: 'auto', marginBottom: 12 }}
              exit={{ opacity: 0, height: 0, marginBottom: 0 }}
              className={`relative flex items-start p-4 rounded-xl border ${config.bg} ${config.border}`}
            >
              <Icon className={`w-5 h-5 mt-0.5 mr-3 flex-shrink-0 ${config.iconColor}`} />
              
              <div className="flex-1 mr-2">
                <h4 className={`text-sm font-bold ${config.text} mb-1`}>
                  {alert.title}
                </h4>
                <p className={`text-sm ${config.text} opacity-90`}>
                  {alert.message}
                </p>
                
                {alert.action && (
                  <button
                    onClick={() => onAction?.(alert)}
                    className={`mt-3 px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${config.button}`}
                  >
                    {alert.action.label}
                  </button>
                )}
              </div>

              <button
                onClick={() => onDismiss(alert.id)}
                className={`p-1 rounded-full hover:bg-black/5 transition-colors ${config.text} opacity-60 hover:opacity-100`}
              >
                <X className="w-4 h-4" />
              </button>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
