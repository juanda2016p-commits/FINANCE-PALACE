import { useState, useMemo } from 'react';
import { motion } from 'motion/react';
import { 
  Info, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle, 
  AlertOctagon, 
  Calendar,
  Target,
  ChevronRight
} from 'lucide-react';
import { Account, BillingCycle, Transaction } from '../../types';
import { calculateCreditMetrics } from '../../utils/financeEngine';

interface CreditStrategicPanelProps {
  account: Account;
  currentCycle: BillingCycle;
  transactions: Transaction[];
}

export default function CreditStrategicPanel({ account, currentCycle, transactions }: CreditStrategicPanelProps) {
  const [targetUtilization, setTargetUtilization] = useState(10); // Default 10%

  // Calculate real-time metrics
  const metrics = useMemo(() => {
    return calculateCreditMetrics(account, transactions, currentCycle);
  }, [account, transactions, currentCycle]);

  const { currentDebt, utilizationRate } = metrics;
  const creditLimit = account.creditLimit || 0;

  // --- Sub-components ---

  const CommitmentPanel = () => (
    <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 mb-6">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-slate-500 text-sm font-semibold uppercase tracking-wider flex items-center gap-2">
            Compromiso de Pago al Corte
            <Info className="w-4 h-4 text-slate-300 cursor-help" />
          </h3>
          <div className="mt-2 flex items-baseline gap-1">
            <span className="text-4xl font-bold text-slate-900">
              ${currentDebt.toLocaleString()}
            </span>
            <span className="text-sm text-slate-400 font-medium">MXN</span>
          </div>
        </div>
        <div className="bg-indigo-50 text-indigo-700 px-3 py-1 rounded-full text-xs font-bold border border-indigo-100 flex items-center gap-1">
          <Calendar className="w-3 h-3" />
          Corte: {new Date(currentCycle.cutoffDate).toLocaleDateString('es-ES', { day: 'numeric', month: 'short' })}
        </div>
      </div>
      <div className="bg-slate-50 rounded-lg p-3 flex items-start gap-3">
        <div className="bg-emerald-100 p-1.5 rounded-full mt-0.5">
          <CheckCircle className="w-4 h-4 text-emerald-600" />
        </div>
        <p className="text-sm text-slate-600 leading-relaxed">
          Este monto <span className="font-bold text-slate-800">no afecta tu liquidez diaria hoy</span>. 
          Es una inversión en tu historial crediticio que pagarás después del corte.
        </p>
      </div>
    </div>
  );

  const UtilizationGauge = () => {
    const radius = 80;
    const stroke = 12;
    const normalizedRadius = radius - stroke * 2;
    const circumference = normalizedRadius * 2 * Math.PI;
    const offset = circumference - (Math.min(utilizationRate, 100) / 100) * circumference * 0.75; // 270 degrees = 0.75
    
    // Determine color
    let color = '#10B981'; // emerald-500
    if (utilizationRate > 50) color = '#EF4444'; // red-500
    else if (utilizationRate > 30) color = '#F97316'; // orange-500
    else if (utilizationRate > 20) color = '#EAB308'; // yellow-500

    return (
      <div className="flex flex-col items-center justify-center p-4 relative">
        <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">Nivel de Uso</h4>
        <div className="relative w-48 h-48 flex items-center justify-center">
          <svg
            height={radius * 2}
            width={radius * 2}
            className="rotate-[135deg]"
          >
            {/* Background Track */}
            <circle
              stroke="#F1F5F9"
              strokeWidth={stroke}
              fill="transparent"
              r={normalizedRadius}
              cx={radius}
              cy={radius}
              strokeDasharray={`${circumference * 0.75} ${circumference * 0.25}`}
              strokeLinecap="round"
            />
            {/* Progress */}
            <motion.circle
              stroke={color}
              strokeWidth={stroke}
              fill="transparent"
              r={normalizedRadius}
              cx={radius}
              cy={radius}
              strokeDasharray={`${circumference * 0.75} ${circumference * 0.25}`}
              strokeDashoffset={offset}
              strokeLinecap="round"
              initial={{ strokeDashoffset: circumference * 0.75 }}
              animate={{ strokeDashoffset: offset }}
              transition={{ duration: 1, ease: "easeOut" }}
            />
          </svg>
          
          {/* Center Text */}
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-3xl font-bold text-slate-800">{utilizationRate.toFixed(1)}%</span>
            <span className="text-xs text-slate-400 font-medium">Utilización</span>
          </div>

          {/* Markers (Simplified positioning) */}
          {/* Ideally we calculate exact positions for 10% and 20% on the arc */}
        </div>
        
        {/* Legend/Zones */}
        <div className="flex gap-2 mt-2">
          <div className="flex items-center gap-1 text-[10px] text-slate-500">
            <div className="w-2 h-2 rounded-full bg-emerald-500"></div> 0-20%
          </div>
          <div className="flex items-center gap-1 text-[10px] text-slate-500">
            <div className="w-2 h-2 rounded-full bg-yellow-500"></div> 21-30%
          </div>
          <div className="flex items-center gap-1 text-[10px] text-slate-500">
            <div className="w-2 h-2 rounded-full bg-red-500"></div> &gt;30%
          </div>
        </div>
      </div>
    );
  };

  const ScoreSimulator = () => {
    const scenarios = [
      { range: '< 10%', impact: 'Neutro', score: '-5 a 0', note: 'Muy bajo, posible inactividad', color: 'text-slate-500', bg: 'bg-slate-50', min: 0, max: 9.9 },
      { range: '10-20%', impact: 'ÓPTIMO', score: '+10 a +20', note: 'Zona ideal para construcción', color: 'text-emerald-600', bg: 'bg-emerald-50', min: 10, max: 20.9 },
      { range: '21-29%', impact: 'Aceptable', score: '0 a +5', note: 'Dentro de rangos seguros', color: 'text-blue-600', bg: 'bg-blue-50', min: 21, max: 29.9 },
      { range: '30-49%', impact: 'Precaución', score: '-10', note: 'Reducir uso recomendado', color: 'text-orange-600', bg: 'bg-orange-50', min: 30, max: 49.9 },
      { range: '>= 50%', impact: 'RIESGO', score: '-25', note: 'Impacto negativo significativo', color: 'text-red-600', bg: 'bg-red-50', min: 50, max: 1000 },
    ];

    return (
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 mb-6">
        <h3 className="text-slate-800 font-bold mb-4 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-indigo-600" />
          Simulador de Impacto en Score
        </h3>
        <div className="overflow-hidden rounded-xl border border-slate-100">
          <table className="w-full text-sm text-left">
            <thead className="bg-slate-50 text-slate-500 font-medium border-b border-slate-100">
              <tr>
                <th className="px-4 py-3">Utilización</th>
                <th className="px-4 py-3">Impacto</th>
                <th className="px-4 py-3">Score Est.</th>
                <th className="px-4 py-3 hidden sm:table-cell">Nota</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {scenarios.map((s, idx) => {
                const isActive = utilizationRate >= s.min && utilizationRate <= s.max;
                return (
                  <tr 
                    key={idx} 
                    className={`transition-colors ${isActive ? 'bg-indigo-50/60' : 'hover:bg-slate-50'}`}
                  >
                    <td className="px-4 py-3 font-medium text-slate-700">{s.range}</td>
                    <td className={`px-4 py-3 font-bold ${s.color}`}>{s.impact}</td>
                    <td className="px-4 py-3 text-slate-600">{s.score} pts</td>
                    <td className="px-4 py-3 text-xs text-slate-500 hidden sm:table-cell">{s.note}</td>
                    {isActive && (
                      <td className="px-2">
                        <motion.div layoutId="active-row-indicator" className="w-2 h-2 rounded-full bg-indigo-600" />
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    );
  };

  const AdjustmentCalculator = () => {
    const targetDebt = creditLimit * (targetUtilization / 100);
    const adjustmentNeeded = Math.max(0, currentDebt - targetDebt);

    return (
      <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-xl mb-6 relative overflow-hidden">
        {/* Background decoration */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-600/20 rounded-full -mr-20 -mt-20 blur-3xl" />
        
        <div className="relative z-10">
          <h3 className="font-bold text-lg mb-1 flex items-center gap-2">
            <Target className="w-5 h-5 text-indigo-400" />
            Calculadora de Ajuste
          </h3>
          <p className="text-slate-400 text-sm mb-6">
            Define tu meta de utilización para el corte y calcula cuánto pagar antes.
          </p>

          <div className="mb-8">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-slate-300">Meta de Utilización</span>
              <span className="font-bold text-indigo-300">{targetUtilization}%</span>
            </div>
            <input 
              type="range" 
              min="1" 
              max="30" 
              step="1"
              value={targetUtilization}
              onChange={(e) => setTargetUtilization(parseInt(e.target.value))}
              className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-500"
            />
            <div className="flex justify-between text-xs text-slate-500 mt-2">
              <span>1%</span>
              <span>10% (Ideal)</span>
              <span>20% (Max Ideal)</span>
              <span>30%</span>
            </div>
          </div>

          <div className="bg-white/10 rounded-xl p-4 border border-white/5 backdrop-blur-sm">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-slate-300">Pago sugerido antes del corte:</span>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-bold text-white">
                ${adjustmentNeeded.toLocaleString()}
              </span>
              <span className="text-xs text-slate-400">
                para llegar al {targetUtilization}%
              </span>
            </div>
            {adjustmentNeeded === 0 && (
              <p className="text-xs text-emerald-400 mt-2 flex items-center gap-1">
                <CheckCircle className="w-3 h-3" />
                ¡Estás dentro del rango objetivo!
              </p>
            )}
          </div>
        </div>
      </div>
    );
  };

  const CycleTimeline = () => {
    const today = new Date();
    const startDate = new Date(currentCycle.startDate);
    const adjustDate = new Date(currentCycle.cutoffDate);
    adjustDate.setDate(adjustDate.getDate() - 1);
    const cutoffDate = new Date(currentCycle.cutoffDate);
    const paymentDate = new Date(currentCycle.paymentDueDate);

    const points = [
      { label: 'Inicio', date: startDate, icon: Calendar },
      { label: 'Hoy', date: today, icon: CheckCircle, active: true },
      { label: 'Ajuste', date: adjustDate, icon: Target },
      { label: 'Corte', date: cutoffDate, icon: AlertOctagon },
      { label: 'Pago', date: paymentDate, icon: AlertTriangle },
    ];

    // Calculate progress percentage for "Today"
    const totalDuration = paymentDate.getTime() - startDate.getTime();
    const elapsed = today.getTime() - startDate.getTime();
    const progress = Math.min(100, Math.max(0, (elapsed / totalDuration) * 100));

    return (
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
        <h3 className="text-slate-800 font-bold mb-6">Línea de Tiempo del Ciclo</h3>
        <div className="relative pt-4 pb-2">
          {/* Progress Bar Background */}
          <div className="absolute top-1/2 left-0 w-full h-1 bg-slate-100 -translate-y-1/2 rounded-full" />
          
          {/* Active Progress */}
          <div 
            className="absolute top-1/2 left-0 h-1 bg-indigo-500 -translate-y-1/2 rounded-full transition-all duration-1000"
            style={{ width: `${progress}%` }}
          />

          {/* Points */}
          <div className="relative flex justify-between">
            {points.map((p, idx) => {
              // Determine if point is passed
              const isPassed = p.date < today;
              const isToday = p.date.toDateString() === today.toDateString();
              
              return (
                <div key={idx} className="flex flex-col items-center group">
                  <div 
                    className={`w-3 h-3 rounded-full border-2 z-10 transition-colors ${
                      isToday ? 'bg-indigo-600 border-indigo-600 scale-125 ring-4 ring-indigo-100' : 
                      isPassed ? 'bg-indigo-600 border-indigo-600' : 
                      'bg-white border-slate-300'
                    }`}
                  />
                  <div className="mt-3 text-center">
                    <p className={`text-[10px] font-bold uppercase tracking-wider ${isToday ? 'text-indigo-600' : 'text-slate-400'}`}>
                      {p.label}
                    </p>
                    <p className="text-[10px] text-slate-400">
                      {p.date.toLocaleDateString('es-ES', { day: 'numeric', month: 'short' })}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div className="lg:col-span-2">
        <h2 className="text-xl font-bold text-slate-900 mb-4">Panel de Crédito Estratégico</h2>
      </div>
      
      {/* Left Column */}
      <div className="space-y-6">
        <CommitmentPanel />
        <div className="bg-white rounded-2xl shadow-sm border border-slate-200">
           <UtilizationGauge />
        </div>
        <AdjustmentCalculator />
      </div>

      {/* Right Column */}
      <div className="space-y-6">
        <ScoreSimulator />
        <CycleTimeline />
      </div>
    </div>
  );
}
