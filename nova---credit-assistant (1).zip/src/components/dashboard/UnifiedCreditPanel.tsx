import React, { useState, useEffect } from 'react';
import { Account, BillingCycle, CyclePhase } from '../../types';
import { getCyclePhase, getCycleStatus } from '../../utils/financeEngine';
import { AlertTriangle, CheckCircle, Info, CreditCard, TrendingUp, Calendar } from 'lucide-react';
import { motion } from 'framer-motion';

interface UnifiedCreditPanelProps {
  account: Account;
  cycle: BillingCycle;
  currentDebt: number;
  creditLimit: number;
  utilizationRate: number;
}

export const UnifiedCreditPanel: React.FC<UnifiedCreditPanelProps> = ({
  account,
  cycle,
  currentDebt,
  creditLimit,
  utilizationRate
}) => {
  const [targetUtilization, setTargetUtilization] = useState(15); // Default target 15%
  const [paymentNeeded, setPaymentNeeded] = useState(0);

  const today = new Date();
  const phase = getCyclePhase(today, account.cutoffDay, account.paymentDueDay);
  
  // Calculate days remaining in cycle (until cutoff)
  const cutoffDate = new Date(cycle.cutoffDate);
  const daysRemaining = Math.max(0, Math.ceil((cutoffDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)));
  
  const status = getCycleStatus(phase, daysRemaining);

  // Calculate payment needed to reach target
  useEffect(() => {
    const targetDebt = creditLimit * (targetUtilization / 100);
    const needed = Math.max(0, currentDebt - targetDebt);
    setPaymentNeeded(needed);
  }, [currentDebt, creditLimit, targetUtilization]);

  // Timeline calculations
  const startDate = new Date(cycle.startDate);
  const totalDays = Math.ceil((cutoffDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
  const daysElapsed = Math.ceil((today.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
  const progress = Math.min(100, Math.max(0, (daysElapsed / totalDays) * 100));

  // Utilization Status
  let utilizationColor = 'text-emerald-500';
  let utilizationLabel = 'Excelente';
  let scoreImpact = 'Positivo';
  
  if (utilizationRate > 50) {
    utilizationColor = 'text-red-500';
    utilizationLabel = 'Alto Riesgo';
    scoreImpact = 'Negativo Alto';
  } else if (utilizationRate > 30) {
    utilizationColor = 'text-orange-500';
    utilizationLabel = 'Regular';
    scoreImpact = 'Negativo Leve';
  } else if (utilizationRate > 10) {
    utilizationColor = 'text-blue-500';
    utilizationLabel = 'Bueno';
    scoreImpact = 'Neutro';
  }

  const availableCredit = creditLimit - currentDebt;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden"
    >
      {/* Header: Main Debt Status */}
      <div className="bg-slate-900 p-6 text-white">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h2 className="text-slate-400 text-sm font-medium uppercase tracking-wider flex items-center gap-2">
              <CreditCard className="w-4 h-4" />
              {account.bankName} • Tarjeta de Crédito
            </h2>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-4xl font-bold tracking-tight">
                ${currentDebt.toLocaleString('es-MX', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
              </span>
              <span className="text-slate-400 text-sm">deuda actual</span>
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm text-slate-400 mb-1">Disponible</div>
            <div className="text-xl font-semibold text-emerald-400">
              ${availableCredit.toLocaleString('es-MX', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
            </div>
          </div>
        </div>

        {/* Progress Bar for Utilization */}
        <div className="relative pt-2">
          <div className="flex justify-between text-xs text-slate-400 mb-1">
            <span>Utilización: {utilizationRate.toFixed(1)}%</span>
            <span>Límite: ${creditLimit.toLocaleString()}</span>
          </div>
          <div className="h-2 bg-slate-700 rounded-full overflow-hidden">
            <motion.div 
              initial={{ width: 0 }}
              animate={{ width: `${Math.min(100, utilizationRate)}%` }}
              className={`h-full rounded-full ${
                utilizationRate > 50 ? 'bg-red-500' : 
                utilizationRate > 30 ? 'bg-orange-500' : 'bg-blue-500'
              }`}
            />
          </div>
        </div>
      </div>

      {/* Body: Timeline & Status */}
      <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* Left: Cycle Timeline */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-slate-900 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-slate-500" />
              Ciclo Actual
            </h3>
            <span className={`px-2 py-1 rounded-full text-xs font-medium ${status.color}`}>
              {status.phase}
            </span>
          </div>
          
          <div className="relative py-4">
            {/* Timeline Track */}
            <div className="h-1.5 bg-slate-100 rounded-full w-full absolute top-1/2 -translate-y-1/2" />
            
            {/* Progress */}
            <div 
              className="h-1.5 bg-indigo-500 rounded-full absolute top-1/2 -translate-y-1/2 transition-all duration-1000"
              style={{ width: `${progress}%` }}
            />

            {/* Start Point */}
            <div className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2 flex flex-col items-center group">
              <div className="w-3 h-3 bg-slate-300 rounded-full border-2 border-white shadow-sm" />
              <span className="text-[10px] text-slate-400 mt-2 opacity-0 group-hover:opacity-100 transition-opacity absolute top-4 whitespace-nowrap">
                Inicio: {startDate.toLocaleDateString('es-MX', { day: 'numeric', month: 'short' })}
              </span>
            </div>

            {/* Current Point (Today) */}
            <div 
              className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 flex flex-col items-center z-10"
              style={{ left: `${progress}%` }}
            >
              <div className="bg-indigo-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded mb-1 shadow-sm">
                HOY
              </div>
              <div className="w-4 h-4 bg-indigo-600 rounded-full border-2 border-white shadow-md" />
            </div>

            {/* End Point (Cutoff) */}
            <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 flex flex-col items-center">
              <div className="w-3 h-3 bg-slate-900 rounded-full border-2 border-white shadow-sm" />
              <div className="text-[10px] font-medium text-slate-900 mt-2 text-center leading-tight">
                Corte<br/>
                <span className="text-slate-500 font-normal">
                  {cutoffDate.toLocaleDateString('es-MX', { day: 'numeric', month: 'short' })}
                </span>
              </div>
            </div>
          </div>

          <div className="text-xs text-slate-500 text-center mt-2">
            Faltan <span className="font-medium text-slate-900">{daysRemaining} días</span> para el corte
          </div>
        </div>

        {/* Right: Calculator & Score */}
        <div className="space-y-6">
          {/* Score Impact Badge */}
          <div className="flex items-center gap-3 bg-slate-50 p-3 rounded-xl border border-slate-100">
            <div className={`p-2 rounded-lg ${
              utilizationRate > 30 ? 'bg-orange-100 text-orange-600' : 'bg-emerald-100 text-emerald-600'
            }`}>
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs text-slate-500 uppercase tracking-wide">Impacto en Score</div>
              <div className="font-medium text-slate-900 flex items-center gap-2">
                {scoreImpact}
                <span className={`text-xs px-1.5 py-0.5 rounded ${
                  utilizationRate > 30 ? 'bg-orange-100 text-orange-700' : 'bg-emerald-100 text-emerald-700'
                }`}>
                  {utilizationLabel}
                </span>
              </div>
            </div>
          </div>

          {/* Mini Calculator */}
          <div className="bg-indigo-50/50 rounded-xl p-4 border border-indigo-100">
            <div className="flex justify-between items-center mb-2">
              <h4 className="text-sm font-medium text-indigo-900 flex items-center gap-1">
                <Info className="w-3 h-3" /> Meta de Utilización
              </h4>
              <span className="text-xs font-bold text-indigo-600">{targetUtilization}%</span>
            </div>
            
            <input 
              type="range" 
              min="1" 
              max="50" 
              value={targetUtilization} 
              onChange={(e) => setTargetUtilization(parseInt(e.target.value))}
              className="w-full h-1.5 bg-indigo-200 rounded-lg appearance-none cursor-pointer accent-indigo-600 mb-3"
            />

            {paymentNeeded > 0 ? (
              <div className="flex items-center gap-2 text-xs text-indigo-800">
                <span>Pagar</span>
                <span className="font-bold bg-white px-2 py-0.5 rounded border border-indigo-100 shadow-sm text-indigo-600">
                  ${paymentNeeded.toLocaleString('es-MX', { maximumFractionDigits: 0 })}
                </span>
                <span>antes del corte para llegar al {targetUtilization}%</span>
              </div>
            ) : (
              <div className="flex items-center gap-2 text-xs text-emerald-700">
                <CheckCircle className="w-3 h-3" />
                <span>¡Meta cumplida! Estás por debajo del {targetUtilization}%</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
};
