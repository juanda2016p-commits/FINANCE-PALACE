import React, { useState, useMemo } from 'react';
import { motion } from 'motion/react';
import { Calendar, AlertCircle, CheckCircle2, Target } from 'lucide-react';
import { Account, BillingCycle } from '../../types';

interface CreditCardTimelineProps {
  account: Account;
  cycle: BillingCycle;
}

export default function CreditCardTimeline({ account, cycle }: CreditCardTimelineProps) {
  const [targetUtilization, setTargetUtilization] = useState(15);

  const today = new Date();
  const cutoffDate = new Date(cycle.cutoffDate);
  const paymentDate = new Date(cycle.paymentDueDate);
  const startDate = new Date(cycle.startDate);

  // Calculate progress percentage for timeline
  const totalDuration = cutoffDate.getTime() - startDate.getTime();
  const elapsed = today.getTime() - startDate.getTime();
  const progress = Math.min(100, Math.max(0, (elapsed / totalDuration) * 100));

  // Goal Calculator
  const currentDebt = account.currentBalance;
  const creditLimit = account.creditLimit || 0;
  const targetDebt = (creditLimit * targetUtilization) / 100;
  const paymentNeeded = Math.max(0, currentDebt - targetDebt);

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('es-ES', { day: 'numeric', month: 'short' });
  };

  const getDaysRemaining = (target: Date) => {
    const diff = Math.ceil((target.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    return diff;
  };

  const daysToCutoff = getDaysRemaining(cutoffDate);
  const daysToPayment = getDaysRemaining(paymentDate);

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 space-y-8">
      
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
          <Calendar className="w-5 h-5 text-indigo-600" />
          Línea de Tiempo del Ciclo
        </h3>
        <span className="text-xs font-medium px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full border border-indigo-100">
          {account.bankName}
        </span>
      </div>

      {/* Timeline Visualization */}
      <div className="relative pt-8 pb-4">
        {/* Main Line */}
        <div className="h-2 bg-slate-100 rounded-full w-full relative">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="absolute top-0 left-0 h-full bg-indigo-500 rounded-full"
          />
        </div>

        {/* Markers */}
        <div className="absolute top-0 w-full h-full pointer-events-none">
          {/* Start Date */}
          <div className="absolute left-0 -top-1 flex flex-col items-center -translate-x-1/2">
            <div className="w-3 h-3 bg-slate-300 rounded-full border-2 border-white shadow-sm mb-2" />
            <span className="text-[10px] font-bold text-slate-400 uppercase">Inicio</span>
            <span className="text-xs font-medium text-slate-600">{formatDate(startDate)}</span>
          </div>

          {/* Today */}
          <motion.div 
            initial={{ left: '0%' }}
            animate={{ left: `${progress}%` }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="absolute -top-2 flex flex-col items-center -translate-x-1/2 z-10"
          >
            <div className="bg-indigo-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-md mb-1">
              HOY
            </div>
            <div className="w-4 h-4 bg-indigo-600 rounded-full border-2 border-white shadow-sm" />
          </motion.div>

          {/* Cutoff Date */}
          <div className="absolute right-0 -top-1 flex flex-col items-center translate-x-1/2">
            <div className="w-3 h-3 bg-slate-800 rounded-full border-2 border-white shadow-sm mb-2" />
            <span className="text-[10px] font-bold text-slate-800 uppercase">Corte</span>
            <span className="text-xs font-bold text-slate-800">{formatDate(cutoffDate)}</span>
            <span className="text-[10px] text-slate-500 mt-0.5">
              {daysToCutoff > 0 ? `${daysToCutoff} días` : 'Pasado'}
            </span>
          </div>
        </div>
        
        {/* Payment Date (Separate visual or extended line?) */}
        {/* Since payment date is usually after cutoff, we might show it as a separate info box or extend the line if needed. 
            For simplicity, let's show it below as a key milestone. */}
      </div>

      <div className="flex justify-end pt-2 border-t border-slate-50 border-dashed">
         <div className="text-right">
            <span className="text-xs text-slate-500 uppercase font-bold tracking-wider">Fecha Límite de Pago</span>
            <div className="text-sm font-bold text-red-600 flex items-center justify-end gap-1">
              {formatDate(paymentDate)}
              <AlertCircle className="w-3 h-3" />
            </div>
         </div>
      </div>

      {/* Goal Calculator */}
      <div className="bg-slate-50 rounded-xl p-5 border border-slate-200">
        <div className="flex items-center gap-2 mb-4">
          <Target className="w-5 h-5 text-emerald-600" />
          <h4 className="font-bold text-slate-800">Calculadora de Meta de Utilización</h4>
        </div>

        <div className="flex flex-col md:flex-row gap-6 items-center">
          <div className="w-full md:w-1/3">
            <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
              Meta Deseada (%)
            </label>
            <div className="flex items-center gap-2">
              <input 
                type="range" 
                min="0" 
                max="100" 
                value={targetUtilization} 
                onChange={(e) => setTargetUtilization(parseInt(e.target.value))}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
              />
              <span className="font-mono font-bold text-slate-900 w-12 text-right">{targetUtilization}%</span>
            </div>
          </div>

          <div className="w-full md:w-2/3 grid grid-cols-2 gap-4">
            <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-sm">
              <span className="text-[10px] text-slate-500 uppercase font-bold">Deuda Actual</span>
              <div className="text-lg font-mono font-medium text-slate-900">
                ${currentDebt.toLocaleString()}
              </div>
            </div>
            
            <div className={`p-3 rounded-lg border shadow-sm ${paymentNeeded > 0 ? 'bg-red-50 border-red-100' : 'bg-emerald-50 border-emerald-100'}`}>
              <span className={`text-[10px] uppercase font-bold ${paymentNeeded > 0 ? 'text-red-600' : 'text-emerald-600'}`}>
                {paymentNeeded > 0 ? 'Pago Necesario' : 'Meta Cumplida'}
              </span>
              <div className={`text-lg font-mono font-bold ${paymentNeeded > 0 ? 'text-red-700' : 'text-emerald-700'}`}>
                ${paymentNeeded.toLocaleString()}
              </div>
            </div>
          </div>
        </div>

        {paymentNeeded > 0 && (
          <div className="mt-4 text-xs text-slate-500 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
            <p>
              Para llegar al <strong>{targetUtilization}%</strong> de utilización antes del corte ({formatDate(cutoffDate)}), 
              debes pagar <strong>${paymentNeeded.toLocaleString()}</strong> adicionales.
            </p>
          </div>
        )}
      </div>

    </div>
  );
}
